# EduSystem - Student Management Portal

A full-stack student management application. Staff sign in, then create, search, update and (as administrators) delete student records. Changes appear live on every connected screen.

- **Backend:** Node.js, Express 5, PostgreSQL, JWT authentication, WebSockets (Socket.IO)
- **Frontend:** React 18 and Vite
- **Ops:** Docker, Docker Compose, Nginx reverse proxy, GitHub Actions, Render blueprint
- **Tests:** Node's built-in test runner with Supertest against a real PostgreSQL database

## Task coverage

| Task | What it asks for | Where it is |
| --- | --- | --- |
| WA-2 REST API | CRUD resource, register/login, hashed passwords, protected routes, status codes, validation, endpoint docs | `backend/src`, [API reference](#api-reference) below |
| WA-3 React frontend | A React client consuming the API | `frontend/` |
| WA-4 Full-stack deployment | Deployed app | `render.yaml`, [Deploy on Render](#deploy-on-render) |
| WA-5 Authentication | Sessions, roles, token handling | access and refresh tokens, roles, lockout, `backend/src/controllers/authController.js` |
| WA-6 Database design | Documented schema | [docs/DATABASE.md](docs/DATABASE.md), `backend/src/db/migrations` |
| WA-7 Testing | Automated tests | `backend/tests`, `npm test` |
| WA-8 Real-time | WebSockets | `backend/src/realtime`, `frontend/src/socket.js` |
| WA-9 CI/CD | Pipeline | `.github/workflows/ci.yml` |
| WA-10 Docker and Nginx | Containers and proxy | `docker-compose.yml`, `backend/Dockerfile`, `frontend/Dockerfile`, `nginx/default.conf` |
| Milestones C1 to C3 | Full-stack, authenticated, production-ready app | the whole repository |

## Project structure

```
.
├── backend/
│   ├── src/
│   │   ├── config/          environment and database pool
│   │   ├── controllers/     request handlers
│   │   ├── db/              migrate.js, seed.js, migrations/*.sql
│   │   ├── middleware/      auth, validation, rate limits, error handler
│   │   ├── models/          SQL queries
│   │   ├── realtime/        Socket.IO server
│   │   ├── routes/
│   │   ├── utils/           crypto, tokens, validation schemas
│   │   ├── app.js           Express app
│   │   └── index.js         server entry point
│   ├── tests/
│   └── Dockerfile
├── frontend/                React app (Vite) and Dockerfile
├── nginx/default.conf
├── docs/DATABASE.md
├── docker-compose.yml
├── render.yaml
└── .github/workflows/ci.yml
```

## Run locally

Requirements: Node.js 20 or newer and a running PostgreSQL server.

1. Create a database:

   ```bash
   createdb edusystem
   ```

2. Install dependencies and generate `backend/.env` with fresh secrets:

   ```bash
   npm run setup
   ```

3. Open `backend/.env` and set `DATABASE_URL` to match your PostgreSQL user and password. Optionally set `ADMIN_EMAIL` and `ADMIN_PASSWORD` to create an administrator automatically.

4. Start the API and the web app in two terminals:

   ```bash
   npm run dev:api     # http://localhost:4000
   npm run dev:web     # http://localhost:5173
   ```

   Open http://localhost:5173. The first account you create becomes the administrator unless you set `ADMIN_EMAIL`.

5. Optional sample students: `npm run seed`.

To run it as a single server the way it runs in production:

```bash
npm run build
npm start          # http://localhost:4000 serves both the API and the built site
```

Set `COOKIE_SECURE=false` when running with `NODE_ENV=production` over plain http.

## Run with Docker

```bash
cp .env.example .env     # fill in POSTGRES_PASSWORD, JWT_ACCESS_SECRET, DATA_ENCRYPTION_KEY
docker compose up --build
```

Open http://localhost:8080. Nginx serves the React build and forwards `/api` and `/socket.io` to the API container. PostgreSQL data lives in the `pgdata` volume. Stop with `docker compose down` (add `-v` to delete the data).

## Deploy on Render

1. Push this repository to GitHub.
2. In Render choose **New > Blueprint** and select the repository. `render.yaml` creates a PostgreSQL database and one web service. The web service builds the React app and the API serves it, so a single URL gives you the whole site.
3. `JWT_ACCESS_SECRET` and `DATA_ENCRYPTION_KEY` are generated for you. Do not change `DATA_ENCRYPTION_KEY` after students have phone numbers stored, because the encrypted values could no longer be read.
4. When the deploy finishes, open the service URL and create the first account (it becomes the administrator). Check `/api/health` returns `{"status":"ok"}`.

Without a blueprint: create a PostgreSQL database, then a Node web service with build command `npm run build`, start command `npm start`, and the environment variables listed below (`DATABASE_URL`, `JWT_ACCESS_SECRET`, `DATA_ENCRYPTION_KEY`, `NODE_ENV=production`, `TRUST_PROXY=true`). If you connect to the database through its external URL instead of the internal one, also set `DB_SSL=true`. Check Render's current plan limits for free databases.

## Environment variables

| Variable | Required | Default | Description |
| --- | --- | --- | --- |
| `DATABASE_URL` | yes | | PostgreSQL connection string |
| `JWT_ACCESS_SECRET` | yes | | Signs access tokens, at least 32 characters |
| `DATA_ENCRYPTION_KEY` | yes | | Derives the key that encrypts phone numbers, at least 32 characters |
| `PORT` | no | 4000 | HTTP port |
| `NODE_ENV` | no | development | `production` makes the refresh cookie Secure by default |
| `DB_SSL` | no | false | Use TLS for the database connection |
| `ACCESS_TOKEN_TTL` | no | 15m | Access token lifetime |
| `REFRESH_TOKEN_DAYS` | no | 7 | Refresh token lifetime |
| `BCRYPT_ROUNDS` | no | 12 | Password hashing cost |
| `CORS_ORIGINS` | no | empty | Comma separated origins allowed cross-origin. Leave empty for same-origin |
| `TRUST_PROXY` | no | false | Set true behind Nginx or Render so client IPs are read correctly |
| `COOKIE_SECURE` | no | true in production | Mark the refresh cookie Secure |
| `AUTO_MIGRATE` | no | true | Apply pending migrations at start |
| `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` | no | | Create this account on first start |

## API reference

Base path: `/api`. Request and response bodies are JSON. Send the access token as `Authorization: Bearer <token>` on every protected route. Without it, or with an invalid or expired one, the API answers `401`.

Errors always look like this:

```json
{ "error": "Validation failed", "details": [{ "field": "email", "message": "Enter a valid email address" }] }
```

`details` is present only for validation errors.

### Status codes

| Code | Meaning |
| --- | --- |
| 200 | OK |
| 201 | Created |
| 204 | Success with no body (logout) |
| 400 | Bad input: failed validation, malformed JSON, invalid id |
| 401 | Missing, invalid or expired token, or wrong credentials |
| 403 | Signed in but not allowed (role) |
| 404 | Record or route not found |
| 409 | Duplicate email or roll number |
| 413 | Request body too large |
| 429 | Rate limit hit or account temporarily locked |
| 500 | Unexpected server error (details are logged, not returned) |

### Health

`GET /api/health` (public)

```json
{ "status": "ok", "database": "up", "uptime": 42 }
```

Returns `503` with `{ "status": "degraded", "database": "down" }` when the database is unreachable.

### Authentication

#### Register
`POST /api/auth/register` (public)

| Field | Rules |
| --- | --- |
| name | 2 to 100 characters |
| email | valid email, stored lower-case |
| password | 8 to 72 characters, at least one letter and one number |

```json
{ "name": "Aarav Sharma", "email": "aarav@example.com", "password": "Passw0rdOK" }
```

`201`

```json
{
  "user": { "id": 1, "name": "Aarav Sharma", "email": "aarav@example.com", "role": "admin" },
  "accessToken": "<jwt>"
}
```

The first account is the administrator, later accounts are `staff`. A refresh token is set as an HttpOnly cookie. `409` if the email is already registered.

#### Login
`POST /api/auth/login` (public)

```json
{ "email": "aarav@example.com", "password": "Passw0rdOK" }
```

`200` returns the same shape as register. Wrong email or password both return `401 {"error":"Invalid email or password"}`. After 5 consecutive failures the account is locked for 15 minutes and the API returns `429`.

#### Refresh
`POST /api/auth/refresh` (uses the refresh cookie, no body)

`200` returns a new `accessToken` and `user` and rotates the cookie. `401` if the cookie is missing, expired or already used.

#### Logout
`POST /api/auth/logout`

`204`. Revokes the refresh token and clears the cookie.

#### Current user
`GET /api/auth/me` (token required)

```json
{ "user": { "id": 1, "name": "Aarav Sharma", "email": "aarav@example.com", "role": "admin" } }
```

### Students

All student routes require a token. Roles: `admin` and `staff` can create, read and update. Only `admin` can delete.

Student object:

```json
{
  "id": 1,
  "name": "Aarav Sharma",
  "rollNumber": "101",
  "batch": "2026",
  "course": "CSE",
  "email": "aarav@example.com",
  "createdAt": "2026-11-18T05:24:05.662Z",
  "updatedAt": "2026-11-18T05:24:05.662Z"
}
```

The single-record, create and update responses also include `"phone"` (decrypted). The list omits it.

#### List
`GET /api/students`

| Query | Default | Description |
| --- | --- | --- |
| search | | matches name, email or roll number, case-insensitive |
| course | | exact course (case-insensitive) |
| batch | | exact batch (case-insensitive) |
| page | 1 | |
| limit | 10 | 1 to 100 |
| sort | id | `id`, `name`, `rollNumber`, `course`, `batch`, `createdAt` |
| order | asc | `asc` or `desc` |

`200`

```json
{
  "data": [ { "id": 1, "name": "Aarav Sharma", "rollNumber": "101", "batch": "2026", "course": "CSE", "email": "aarav@example.com", "createdAt": "...", "updatedAt": "..." } ],
  "meta": { "page": 1, "limit": 10, "total": 1, "totalPages": 1 }
}
```

#### Dashboard counts
`GET /api/students/stats`

```json
{ "totalStudents": 1, "totalCourses": 1, "totalBatches": 1 }
```

#### Get one
`GET /api/students/:id` returns `200 { "data": { ...student, "phone": "+919876543210" } }` or `404 {"error":"Student not found"}`. A non-numeric id returns `400`.

#### Create
`POST /api/students`

| Field | Rules |
| --- | --- |
| name | 2 to 100 characters |
| rollNumber | 1 to 30 characters: letters, numbers, `-`, `_`, `/`. Unique, case-insensitive |
| batch | 1 to 20 characters |
| course | 1 to 80 characters |
| email | valid email, unique, case-insensitive |
| phone | optional, 7 to 15 digits with optional leading `+`. Stored encrypted |

```json
{ "name": "Aarav Sharma", "rollNumber": "101", "batch": "2026", "course": "CSE", "email": "aarav@example.com", "phone": "+919876543210" }
```

`201 { "data": { ...student, "phone": "+919876543210" } }`. `400` for invalid input, `409` for a duplicate roll number or email:

```json
{ "error": "A student with this roll number already exists" }
```

#### Update
`PUT /api/students/:id` takes the same body as create and replaces the record. `200` with the updated student, `404` if it does not exist, `409` on duplicates.

#### Delete
`DELETE /api/students/:id` (admin only)

`200 { "message": "Student deleted", "id": 1 }`. `403` for staff, `404` if it does not exist.

### Audit log

`GET /api/audit-logs?limit=50` (admin only) returns the newest entries first: logins, failed logins, registrations and student create, update and delete actions.

### Real-time events

Connect with Socket.IO to the same origin and pass the access token: `io({ auth: { token } })`. Connections without a valid token are refused. The server emits:

| Event | Payload |
| --- | --- |
| `student:created` | `{ student, by }` |
| `student:updated` | `{ student, by }` |
| `student:deleted` | `{ id, by }` |
| `presence` | `{ online }` number of connected clients |

`by` is the id of the user who made the change. Payloads never contain phone numbers.

## Security notes

- Passwords are hashed with bcrypt. Plain passwords are never stored or logged.
- Access tokens are short-lived JWTs (15 minutes) held in memory by the React app. The refresh token is a random value in an HttpOnly, SameSite=Strict cookie scoped to `/api/auth`, stored in the database only as a SHA-256 hash. Tokens rotate on every use and reuse revokes the whole session family.
- Login errors are identical for unknown emails and wrong passwords, with a dummy hash comparison so response time does not reveal which accounts exist. Accounts lock for 15 minutes after 5 failed attempts.
- Student phone numbers are encrypted with AES-256-GCM before they reach the database.
- Every SQL statement is parameterised. Search input has LIKE wildcards escaped. Request bodies are validated with Zod and limited to 50 KB.
- Helmet sets security headers including a Content Security Policy. Rate limiting is applied to the API and more strictly to authentication routes.
- Internal error details are logged on the server and never sent to clients.
- Role checks are enforced on the server. Hiding the delete button in the UI is only a convenience.

## Testing

```bash
cd backend
npm install
TEST_DATABASE_URL=postgresql://user:password@localhost:5432/edusystem_test npm test
```

Create the test database first (`createdb edusystem_test`). The suite resets its tables, so use a database that holds no real data. It covers registration and login rules, password hashing, lockout, token rotation and reuse detection, route protection, validation, duplicates, role permissions, pagination and search, field encryption, the audit trail and the WebSocket events.

## CI/CD

`.github/workflows/ci.yml` runs on every push and pull request:

1. **backend** - installs dependencies and runs the test suite against a PostgreSQL service container.
2. **frontend** - installs and builds the React app.
3. **docker** - builds both images, starts the full Compose stack and runs a smoke test through Nginx (health check, register, create a student).
4. **deploy** - on pushes to `main`, calls the Render deploy hook if the `RENDER_DEPLOY_HOOK_URL` secret is set. Render can also deploy directly from GitHub without it.
