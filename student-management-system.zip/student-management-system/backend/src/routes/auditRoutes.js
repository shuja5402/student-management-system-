import { Router } from 'express';
import { authenticate, requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { auditQuery } from '../utils/schemas.js';
import * as audit from '../models/audit.js';

const router = Router();

router.get('/', authenticate, requireRole('admin'), validate({ query: auditQuery }), async (req, res) => {
  res.json({ data: await audit.latest(req.valid.query.limit) });
});

export default router;
