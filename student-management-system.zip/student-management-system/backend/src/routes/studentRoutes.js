import { Router } from 'express';
import { validate } from '../middleware/validate.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { idParams, listQuery, studentSchema } from '../utils/schemas.js';
import * as ctrl from '../controllers/studentController.js';

const router = Router();

router.use(authenticate);

router.get('/', validate({ query: listQuery }), ctrl.list);
router.get('/stats', ctrl.stats);
router.get('/:id', validate({ params: idParams }), ctrl.get);
router.post('/', validate({ body: studentSchema }), ctrl.create);
router.put('/:id', validate({ params: idParams, body: studentSchema }), ctrl.update);
router.delete('/:id', requireRole('admin'), validate({ params: idParams }), ctrl.remove);

export default router;
