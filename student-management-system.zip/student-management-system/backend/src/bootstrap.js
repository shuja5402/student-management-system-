import bcrypt from 'bcryptjs';
import { env } from './config/env.js';
import * as users from './models/user.js';

export async function ensureAdmin() {
  if (!env.adminEmail || !env.adminPassword) return;
  if (await users.findByEmail(env.adminEmail)) return;
  const passwordHash = await bcrypt.hash(env.adminPassword, env.bcryptRounds);
  const admin = await users.createUser({ name: env.adminName, email: env.adminEmail.toLowerCase(), passwordHash });
  console.log(`Created initial account for ${admin.email} (role: ${admin.role})`);
}
