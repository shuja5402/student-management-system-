import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';

const ISSUER = 'edusystem';

export function signAccessToken(user) {
  return jwt.sign({ role: user.role }, env.jwtSecret, {
    algorithm: 'HS256',
    issuer: ISSUER,
    subject: String(user.id),
    expiresIn: env.accessTtl,
  });
}

export function verifyAccessToken(token) {
  return jwt.verify(token, env.jwtSecret, { algorithms: ['HS256'], issuer: ISSUER });
}
