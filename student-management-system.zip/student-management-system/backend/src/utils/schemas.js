import { z } from 'zod';

const name = z.string().trim().min(2, 'Name must be at least 2 characters').max(100, 'Name must be at most 100 characters');
const email = z.string().trim().toLowerCase().email('Enter a valid email address').max(255, 'Email is too long');

export const registerSchema = z.object({
  name,
  email,
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(72, 'Password must be at most 72 characters')
    .regex(/[A-Za-z]/, 'Password must contain a letter')
    .regex(/[0-9]/, 'Password must contain a number'),
});

export const loginSchema = z.object({
  email,
  password: z.string().min(1, 'Password is required').max(72),
});

const phone = z
  .union([z.string().trim().regex(/^\+?[0-9]{7,15}$/, 'Phone must be 7 to 15 digits, with an optional leading +'), z.literal(''), z.null()])
  .optional()
  .transform((v) => (v ? v : null));

export const studentSchema = z.object({
  name,
  rollNumber: z
    .string()
    .trim()
    .min(1, 'Roll number is required')
    .max(30, 'Roll number must be at most 30 characters')
    .regex(/^[A-Za-z0-9][A-Za-z0-9\-_/]*$/, 'Roll number may contain letters, numbers, - _ and /'),
  batch: z.string().trim().min(1, 'Batch is required').max(20, 'Batch must be at most 20 characters'),
  course: z.string().trim().min(1, 'Course is required').max(80, 'Course must be at most 80 characters'),
  email,
  phone,
});

export const idParams = z.object({
  id: z.coerce.number().int('Invalid id').positive('Invalid id').max(2147483647, 'Invalid id'),
});

export const listQuery = z.object({
  search: z.string().trim().max(100).optional(),
  course: z.string().trim().max(80).optional(),
  batch: z.string().trim().max(20).optional(),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(10),
  sort: z.enum(['id', 'name', 'rollNumber', 'course', 'batch', 'createdAt']).default('id'),
  order: z.enum(['asc', 'desc']).default('asc'),
});

export const auditQuery = z.object({
  limit: z.coerce.number().int().min(1).max(200).default(50),
});
