import { query, withTransaction } from '../config/db.js';

const PUBLIC = 'id, name, email, role, created_at AS "createdAt", last_login_at AS "lastLoginAt"';

export async function createUser({ name, email, passwordHash }) {
  return withTransaction(async (client) => {
    await client.query('SELECT pg_advisory_xact_lock(7001)');
    const { rows: existing } = await client.query('SELECT 1 FROM users LIMIT 1');
    const role = existing.length ? 'staff' : 'admin';
    const { rows } = await client.query(
      `INSERT INTO users (name, email, password_hash, role) VALUES ($1, $2, $3, $4) RETURNING ${PUBLIC}`,
      [name, email, passwordHash, role]
    );
    return rows[0];
  });
}

export async function findByEmail(email) {
  const { rows } = await query('SELECT * FROM users WHERE lower(email) = lower($1)', [email]);
  return rows[0] || null;
}

export async function findById(id) {
  const { rows } = await query(`SELECT ${PUBLIC} FROM users WHERE id = $1`, [id]);
  return rows[0] || null;
}

export async function registerFailure(id) {
  await query(
    `UPDATE users
        SET locked_until = CASE WHEN failed_attempts + 1 >= 5 THEN now() + interval '15 minutes' ELSE locked_until END,
            failed_attempts = CASE WHEN failed_attempts + 1 >= 5 THEN 0 ELSE failed_attempts + 1 END,
            updated_at = now()
      WHERE id = $1`,
    [id]
  );
}

export async function registerSuccess(id) {
  await query('UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login_at = now() WHERE id = $1', [id]);
}

export const toPublic = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role });
