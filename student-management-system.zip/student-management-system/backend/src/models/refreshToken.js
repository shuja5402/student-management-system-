import { query } from '../config/db.js';
import { env } from '../config/env.js';
import { randomToken, sha256, uuid } from '../utils/crypto.js';

export async function issue(userId, familyId = uuid()) {
  const raw = randomToken();
  await query(
    `INSERT INTO refresh_tokens (user_id, token_hash, family_id, expires_at)
     VALUES ($1, $2, $3, now() + make_interval(days => $4))`,
    [userId, sha256(raw), familyId, env.refreshDays]
  );
  return raw;
}

export async function consume(raw) {
  const hash = sha256(raw);
  const { rows } = await query(
    `UPDATE refresh_tokens SET revoked_at = now()
      WHERE token_hash = $1 AND revoked_at IS NULL AND expires_at > now()
      RETURNING user_id AS "userId", family_id AS "familyId"`,
    [hash]
  );
  if (rows[0]) return { ok: true, ...rows[0] };

  const { rows: known } = await query('SELECT family_id AS "familyId" FROM refresh_tokens WHERE token_hash = $1', [hash]);
  if (known[0]) await revokeFamily(known[0].familyId);
  return { ok: false };
}

export async function revoke(raw) {
  await query('UPDATE refresh_tokens SET revoked_at = now() WHERE token_hash = $1 AND revoked_at IS NULL', [sha256(raw)]);
}

export async function revokeFamily(familyId) {
  await query('UPDATE refresh_tokens SET revoked_at = now() WHERE family_id = $1 AND revoked_at IS NULL', [familyId]);
}

export async function purgeExpired() {
  await query("DELETE FROM refresh_tokens WHERE expires_at < now() - interval '1 day'");
}
