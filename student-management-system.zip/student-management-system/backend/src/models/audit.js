import { query } from '../config/db.js';

export async function record({ userId = null, action, entity, entityId = null, details = null, ip = null }) {
  try {
    await query(
      'INSERT INTO audit_logs (user_id, action, entity, entity_id, details, ip_address) VALUES ($1, $2, $3, $4, $5, $6)',
      [userId, action, entity, entityId, details ? JSON.stringify(details) : null, ip]
    );
  } catch (err) {
    console.error('Audit log write failed:', err.message);
  }
}

export async function latest(limit) {
  const { rows } = await query(
    `SELECT a.id, a.action, a.entity, a.entity_id AS "entityId", a.details, a.ip_address AS "ipAddress",
            a.created_at AS "createdAt", a.user_id AS "userId", u.email AS "userEmail"
       FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
      ORDER BY a.id DESC LIMIT $1`,
    [limit]
  );
  return rows;
}
