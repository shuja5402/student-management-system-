import { query } from '../config/db.js';
import { decrypt, encrypt } from '../utils/crypto.js';

const SORT = {
  id: 'id',
  name: 'lower(name)',
  rollNumber: 'lower(roll_number)',
  course: 'lower(course)',
  batch: 'lower(batch)',
  createdAt: 'created_at',
};

const COLUMNS = 'id, name, roll_number, batch, course, email, phone_encrypted, created_at, updated_at';

export function toApi(row, { withPhone = false } = {}) {
  const student = {
    id: row.id,
    name: row.name,
    rollNumber: row.roll_number,
    batch: row.batch,
    course: row.course,
    email: row.email,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
  if (withPhone) student.phone = decrypt(row.phone_encrypted);
  return student;
}

const escapeLike = (value) => value.replace(/[\\%_]/g, (c) => `\\${c}`);

export async function list({ search, course, batch, page, limit, sort, order }) {
  const where = [];
  const params = [];
  if (search) {
    params.push(`%${escapeLike(search)}%`);
    where.push(`(name ILIKE $${params.length} OR email ILIKE $${params.length} OR roll_number ILIKE $${params.length})`);
  }
  if (course) {
    params.push(course);
    where.push(`lower(course) = lower($${params.length})`);
  }
  if (batch) {
    params.push(batch);
    where.push(`lower(batch) = lower($${params.length})`);
  }
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const direction = order === 'desc' ? 'DESC' : 'ASC';

  const [{ rows: countRows }, { rows }] = await Promise.all([
    query(`SELECT COUNT(*) AS total FROM students ${clause}`, params),
    query(
      `SELECT ${COLUMNS} FROM students ${clause}
        ORDER BY ${SORT[sort]} ${direction}, id ASC
        LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, limit, (page - 1) * limit]
    ),
  ]);
  const total = countRows[0].total;
  return { rows: rows.map((r) => toApi(r)), total };
}

export async function stats() {
  const { rows } = await query(
    `SELECT COUNT(*) AS students, COUNT(DISTINCT lower(course)) AS courses, COUNT(DISTINCT lower(batch)) AS batches FROM students`
  );
  return rows[0];
}

export async function findById(id) {
  const { rows } = await query(`SELECT ${COLUMNS} FROM students WHERE id = $1`, [id]);
  return rows[0] || null;
}

export async function create(data, userId) {
  const { rows } = await query(
    `INSERT INTO students (name, roll_number, batch, course, email, phone_encrypted, created_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING ${COLUMNS}`,
    [data.name, data.rollNumber, data.batch, data.course, data.email, encrypt(data.phone), userId]
  );
  return rows[0];
}

export async function update(id, data) {
  const { rows } = await query(
    `UPDATE students
        SET name = $1, roll_number = $2, batch = $3, course = $4, email = $5, phone_encrypted = $6, updated_at = now()
      WHERE id = $7 RETURNING ${COLUMNS}`,
    [data.name, data.rollNumber, data.batch, data.course, data.email, encrypt(data.phone), id]
  );
  return rows[0] || null;
}

export async function remove(id) {
  const { rows } = await query('DELETE FROM students WHERE id = $1 RETURNING id, roll_number', [id]);
  return rows[0] || null;
}
