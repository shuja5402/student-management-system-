import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

dotenv.config({ path: path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../.env') });

const flag = (value, fallback = false) => {
  if (value === undefined || value === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(value).toLowerCase());
};

const nodeEnv = process.env.NODE_ENV || 'development';

export const env = {
  nodeEnv,
  isProd: nodeEnv === 'production',
  isTest: nodeEnv === 'test',
  port: Number(process.env.PORT) || 4000,
  databaseUrl: process.env.DATABASE_URL,
  dbSsl: flag(process.env.DB_SSL),
  jwtSecret: process.env.JWT_ACCESS_SECRET,
  accessTtl: process.env.ACCESS_TOKEN_TTL || '15m',
  refreshDays: Number(process.env.REFRESH_TOKEN_DAYS) || 7,
  encryptionKey: process.env.DATA_ENCRYPTION_KEY,
  bcryptRounds: Number(process.env.BCRYPT_ROUNDS) || 12,
  corsOrigins: (process.env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
  trustProxy: flag(process.env.TRUST_PROXY),
  cookieSecure: flag(process.env.COOKIE_SECURE, nodeEnv === 'production'),
  autoMigrate: flag(process.env.AUTO_MIGRATE, true),
  adminName: process.env.ADMIN_NAME || 'Administrator',
  adminEmail: process.env.ADMIN_EMAIL,
  adminPassword: process.env.ADMIN_PASSWORD,
};

const problems = [];
if (!env.databaseUrl && !process.env.PGHOST) problems.push('DATABASE_URL (or PGHOST/PGDATABASE/PGUSER/PGPASSWORD)');
if (!env.jwtSecret) problems.push('JWT_ACCESS_SECRET');
if (!env.encryptionKey) problems.push('DATA_ENCRYPTION_KEY');
if (problems.length) {
  throw new Error(`Missing required environment variables: ${problems.join(', ')}. Copy .env.example to .env and fill it in.`);
}
if (env.jwtSecret.length < 32) throw new Error('JWT_ACCESS_SECRET must be at least 32 characters long');
if (env.encryptionKey.length < 32) throw new Error('DATA_ENCRYPTION_KEY must be at least 32 characters long');
