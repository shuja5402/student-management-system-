import { AppError } from '../utils/errors.js';

const UNIQUE_MESSAGES = {
  users_email_lower_uidx: 'An account with this email already exists',
  students_roll_number_lower_uidx: 'A student with this roll number already exists',
  students_email_lower_uidx: 'A student with this email already exists',
};

export function notFound(_req, _res, next) {
  next(new AppError(404, 'Route not found'));
}

export function errorHandler(err, _req, res, _next) {
  if (err instanceof AppError) {
    const body = { error: err.message };
    if (err.details) body.details = err.details;
    return res.status(err.status).json(body);
  }
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON body' });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request body is too large' });
  if (err.code === '23505') {
    return res.status(409).json({ error: UNIQUE_MESSAGES[err.constraint] || 'Duplicate value' });
  }
  if (err.code === '22P02' || err.code === '22003') return res.status(400).json({ error: 'Invalid input' });
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
}
