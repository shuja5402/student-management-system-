import { AppError } from '../utils/errors.js';

export const validate = (schemas) => (req, _res, next) => {
  const valid = {};
  const problems = [];
  for (const part of ['params', 'query', 'body']) {
    if (!schemas[part]) continue;
    const result = schemas[part].safeParse(req[part] ?? {});
    if (result.success) {
      valid[part] = result.data;
    } else {
      for (const issue of result.error.issues) {
        const field = issue.path.join('.') || part;
        if (!problems.some((p) => p.field === field)) problems.push({ field, message: issue.message });
      }
    }
  }
  if (problems.length) return next(new AppError(400, 'Validation failed', problems));
  req.valid = valid;
  next();
};
