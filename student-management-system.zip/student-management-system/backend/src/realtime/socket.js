import { Server } from 'socket.io';
import { env } from '../config/env.js';
import { verifyAccessToken } from '../utils/tokens.js';
import { setIo } from './events.js';

export function attachSocket(httpServer) {
  const io = new Server(httpServer, {
    serveClient: false,
    cors: env.corsOrigins.length ? { origin: env.corsOrigins, credentials: true } : undefined,
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('Authentication required'));
    try {
      const payload = verifyAccessToken(token);
      socket.data.user = { id: Number(payload.sub), role: payload.role };
      next();
    } catch {
      next(new Error('Invalid or expired token'));
    }
  });

  const announce = () => io.emit('presence', { online: io.of('/').sockets.size });

  io.on('connection', (socket) => {
    announce();
    socket.on('disconnect', announce);
  });

  setIo(io);
  return io;
}
