let io = null;

export function setIo(server) {
  io = server;
}

export function broadcast(event, payload) {
  if (io) io.emit(event, payload);
}
