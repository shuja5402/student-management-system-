import http from 'node:http';
import { env } from './config/env.js';
import { pool } from './config/db.js';
import { migrate } from './db/migrate.js';
import { createApp } from './app.js';
import { attachSocket } from './realtime/socket.js';
import { ensureAdmin } from './bootstrap.js';

async function main() {
  if (env.autoMigrate) {
    const applied = await migrate();
    if (applied.length) console.log(`Applied migrations: ${applied.join(', ')}`);
  }
  await ensureAdmin();

  const server = http.createServer(createApp());
  attachSocket(server);
  server.listen(env.port, () => console.log(`EduSystem API listening on port ${env.port} (${env.nodeEnv})`));

  const shutdown = (signal) => {
    console.log(`${signal} received, shutting down`);
    server.close(async () => {
      await pool.end();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch((err) => {
  console.error('Failed to start:', err.message);
  process.exit(1);
});
