import { AppError } from '../utils/errors.js';
import * as students from '../models/student.js';
import * as audit from '../models/audit.js';
import { broadcast } from '../realtime/events.js';

export async function list(req, res) {
  const q = req.valid.query;
  const { rows, total } = await students.list(q);
  res.json({
    data: rows,
    meta: { page: q.page, limit: q.limit, total, totalPages: Math.max(1, Math.ceil(total / q.limit)) },
  });
}

export async function stats(_req, res) {
  const s = await students.stats();
  res.json({ totalStudents: s.students, totalCourses: s.courses, totalBatches: s.batches });
}

export async function get(req, res) {
  const row = await students.findById(req.valid.params.id);
  if (!row) throw new AppError(404, 'Student not found');
  res.json({ data: students.toApi(row, { withPhone: true }) });
}

export async function create(req, res) {
  const row = await students.create(req.valid.body, req.user.id);
  await audit.record({
    userId: req.user.id, action: 'create', entity: 'student', entityId: row.id,
    details: { rollNumber: row.roll_number }, ip: req.ip,
  });
  broadcast('student:created', { student: students.toApi(row), by: req.user.id });
  res.status(201).json({ data: students.toApi(row, { withPhone: true }) });
}

export async function update(req, res) {
  const row = await students.update(req.valid.params.id, req.valid.body);
  if (!row) throw new AppError(404, 'Student not found');
  await audit.record({
    userId: req.user.id, action: 'update', entity: 'student', entityId: row.id,
    details: { rollNumber: row.roll_number }, ip: req.ip,
  });
  broadcast('student:updated', { student: students.toApi(row), by: req.user.id });
  res.json({ data: students.toApi(row, { withPhone: true }) });
}

export async function remove(req, res) {
  const removed = await students.remove(req.valid.params.id);
  if (!removed) throw new AppError(404, 'Student not found');
  await audit.record({
    userId: req.user.id, action: 'delete', entity: 'student', entityId: removed.id,
    details: { rollNumber: removed.roll_number }, ip: req.ip,
  });
  broadcast('student:deleted', { id: removed.id, by: req.user.id });
  res.json({ message: 'Student deleted', id: removed.id });
}
