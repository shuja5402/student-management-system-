import bcrypt from 'bcryptjs';
import { env } from '../config/env.js';
import { AppError } from '../utils/errors.js';
import { signAccessToken } from '../utils/tokens.js';
import * as users from '../models/user.js';
import * as refreshTokens from '../models/refreshToken.js';
import * as audit from '../models/audit.js';

const COOKIE = 'edusystem_rt';
const dummyHash = bcrypt.hashSync('not-a-real-password-1', env.bcryptRounds);

const cookieOptions = () => ({
  httpOnly: true,
  secure: env.cookieSecure,
  sameSite: 'strict',
  path: '/api/auth',
  maxAge: env.refreshDays * 24 * 60 * 60 * 1000,
});

async function startSession(res, user) {
  const refresh = await refreshTokens.issue(user.id);
  res.cookie(COOKIE, refresh, cookieOptions());
  return { user: users.toPublic(user), accessToken: signAccessToken(user) };
}

export async function register(req, res) {
  const { name, email, password } = req.valid.body;
  const passwordHash = await bcrypt.hash(password, env.bcryptRounds);
  const user = await users.createUser({ name, email, passwordHash });
  await audit.record({ userId: user.id, action: 'register', entity: 'user', entityId: user.id, ip: req.ip });
  res.status(201).json(await startSession(res, user));
}

export async function login(req, res) {
  const { email, password } = req.valid.body;
  const user = await users.findByEmail(email);

  if (user?.locked_until && new Date(user.locked_until) > new Date()) {
    throw new AppError(429, 'Account temporarily locked after repeated failed logins. Try again in a few minutes.');
  }

  const matches = await bcrypt.compare(password, user ? user.password_hash : dummyHash);
  if (!user || !matches) {
    if (user) await users.registerFailure(user.id);
    await audit.record({ userId: user?.id ?? null, action: 'login_failed', entity: 'user', entityId: user?.id ?? null, ip: req.ip });
    throw new AppError(401, 'Invalid email or password');
  }

  await users.registerSuccess(user.id);
  await refreshTokens.purgeExpired();
  await audit.record({ userId: user.id, action: 'login', entity: 'user', entityId: user.id, ip: req.ip });
  res.json(await startSession(res, user));
}

export async function refresh(req, res) {
  const raw = req.cookies?.[COOKIE];
  if (!raw) throw new AppError(401, 'Session expired, please sign in again');

  const result = await refreshTokens.consume(raw);
  if (!result.ok) {
    res.clearCookie(COOKIE, { path: '/api/auth' });
    throw new AppError(401, 'Session expired, please sign in again');
  }
  const user = await users.findById(result.userId);
  if (!user) throw new AppError(401, 'Session expired, please sign in again');

  const next = await refreshTokens.issue(user.id, result.familyId);
  res.cookie(COOKIE, next, cookieOptions());
  res.json({ user: users.toPublic(user), accessToken: signAccessToken(user) });
}

export async function logout(req, res) {
  const raw = req.cookies?.[COOKIE];
  if (raw) await refreshTokens.revoke(raw);
  res.clearCookie(COOKIE, { path: '/api/auth' });
  res.status(204).end();
}

export async function me(req, res) {
  const user = await users.findById(req.user.id);
  if (!user) throw new AppError(401, 'Account no longer exists');
  res.json({ user: users.toPublic(user) });
}
