CREATE TABLE users (
  id               INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name             VARCHAR(100) NOT NULL,
  email            VARCHAR(255) NOT NULL,
  password_hash    TEXT NOT NULL,
  role             VARCHAR(10) NOT NULL DEFAULT 'staff' CHECK (role IN ('admin', 'staff')),
  failed_attempts  INTEGER NOT NULL DEFAULT 0,
  locked_until     TIMESTAMPTZ,
  last_login_at    TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX users_email_lower_uidx ON users (lower(email));

CREATE TABLE refresh_tokens (
  id          INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users (id) ON DELETE CASCADE,
  token_hash  CHAR(64) NOT NULL UNIQUE,
  family_id   UUID NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  revoked_at  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX refresh_tokens_user_idx ON refresh_tokens (user_id);
CREATE INDEX refresh_tokens_family_idx ON refresh_tokens (family_id);

CREATE TABLE students (
  id               INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name             VARCHAR(100) NOT NULL,
  roll_number      VARCHAR(30) NOT NULL,
  batch            VARCHAR(20) NOT NULL,
  course           VARCHAR(80) NOT NULL,
  email            VARCHAR(255) NOT NULL,
  phone_encrypted  TEXT,
  created_by       INTEGER REFERENCES users (id) ON DELETE SET NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX students_roll_number_lower_uidx ON students (lower(roll_number));
CREATE UNIQUE INDEX students_email_lower_uidx ON students (lower(email));
CREATE INDEX students_course_idx ON students (lower(course));
CREATE INDEX students_batch_idx ON students (lower(batch));

CREATE TABLE audit_logs (
  id          INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id     INTEGER REFERENCES users (id) ON DELETE SET NULL,
  action      VARCHAR(40) NOT NULL,
  entity      VARCHAR(40) NOT NULL,
  entity_id   INTEGER,
  details     JSONB,
  ip_address  VARCHAR(64),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX audit_logs_created_idx ON audit_logs (created_at DESC);
CREATE INDEX audit_logs_user_idx ON audit_logs (user_id);
