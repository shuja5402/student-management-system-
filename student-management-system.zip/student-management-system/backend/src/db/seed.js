import { pool, query } from '../config/db.js';
import { migrate } from './migrate.js';

const sample = [
  ['Aarav Sharma', '101', '2026', 'CSE', 'aarav.sharma@example.com'],
  ['Priya Reddy', '102', '2026', 'ECE', 'priya.reddy@example.com'],
  ['Mohammed Faizan', '103', '2025', 'Mechanical', 'faizan.m@example.com'],
  ['Ananya Iyer', '104', '2027', 'CSE', 'ananya.iyer@example.com'],
];

await migrate();
let added = 0;
for (const [name, roll, batch, course, email] of sample) {
  const result = await query(
    `INSERT INTO students (name, roll_number, batch, course, email) VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING`,
    [name, roll, batch, course, email]
  );
  added += result.rowCount;
}
console.log(`Seed finished, ${added} student(s) added`);
await pool.end();
